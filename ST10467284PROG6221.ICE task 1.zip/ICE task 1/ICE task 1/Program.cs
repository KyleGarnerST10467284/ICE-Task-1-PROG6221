﻿//Reference: W3Schools (n.d.) C# Type Casting. [Online] Available at: https://www.w3schools.com/cs/cs_type_casting.php(Accessed: 19 February 2026).
using System;

class Program
{
    static void Main()
    {
        //The title text
        Console.WriteLine("** Student Grade Calculator **");

        //asks the user to input name and surname
        Console.Write("Enter student's name (first and surname): ");
        var inputName = Console.ReadLine();

        //split the name by spaces 
        var parts = inputName.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        //keeps asking until the user enters at least 2:first + surname
        while (parts.Length < 2)
        {
            Console.Write("Invalid name. Enter first and surname: ");
            inputName = Console.ReadLine();
            parts = inputName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        }

        //capitalize first letter of each
        var studentName = Capitalize(parts[0]) + " " + Capitalize(parts[1]);

        //reads out 3 scores from the user 
        var s1 = ReadScore("Enter score 1 (out of 100): ");
        var s2 = ReadScore("Enter score 2 (out of 100): ");
        var s3 = ReadScore("Enter score 3 (out of 100): ");

        //calculates mean, uses 3.0 so it becomes a decimal answer
        var avg = (s1 + s2 + s3) / 3.0;

        //dedicates the letter grade depending on the inputted number
        char grade;
        if (avg >= 90) grade = 'A';
        else if (avg >= 80) grade = 'B';
        else if (avg >= 70) grade = 'C';
        else if (avg >= 60) grade = 'D';
        else grade = 'F';

        //this prints the final report
        Console.WriteLine();
        Console.WriteLine("** Grade Report **");
        Console.WriteLine("Student Name: " + studentName);
        Console.WriteLine("Scores: " + s1 + "%, " + s2 + "%, " + s3 + "%");
        Console.WriteLine("Average Score: " + avg.ToString("0.00") + "%");
        Console.WriteLine("Final Grade: " + grade);
    }

    static int ReadScore(string prompt)
    {
        int score;

        //it asks for a score
        Console.Write(prompt);

        //keeps asking til input is valid number between 0 and 100
        while (!int.TryParse(Console.ReadLine(), out score) || score < 0 || score > 100)
        {
            Console.Write("Invalid score. Enter 0 to 100: ");
        }

        // Return the valid score
        return score;
    }

    static string Capitalize(string word)
    {
       //makes the word lowercase first
        word = word.ToLower();

        //the first letter uppercase and keeps the rest
        return char.ToUpper(word[0]) + word.Substring(1);
    }
}